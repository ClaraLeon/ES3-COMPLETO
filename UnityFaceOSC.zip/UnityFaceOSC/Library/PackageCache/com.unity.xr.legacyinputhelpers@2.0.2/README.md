# Legacy Input Helpers Package

This package is the new home of the Tracked Pose Driver monobehaviour. The Tracked Pose Driver is intended to make it easy to make Game Objects track input device data.

