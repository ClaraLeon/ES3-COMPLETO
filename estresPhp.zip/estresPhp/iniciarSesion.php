<?php
//conexion a la BD
//echo "HOLA SOY LA CONEXION - EN CASA";
	$dbname = 'estres';
	$dbuser = 'estresUsuario';
	$dbpass = 'estres2020';
	$dbhost = 'localhost';

	//usuario: estresUsuario
	//clave: estres2020
	
//CONEXIÓN DE  BD CLASE
/*$dbname = 'UnityDB';
$dbuser = 'camilo';
$dbpass = 'Noviembre2018';
$dbhost = 'localhost';*/

//conectarce al servidor mysql  (servidor,user,pasword,NombreBD)
$conect = new mysqli($dbhost, $dbuser, $dbpass,$dbname);

//recibe los datos de unity, usamos el valor de estas variables
$email = $_REQUEST['ema'];
$contra = $_REQUEST['con'];


//pregunto si el id de usuario ya esta en la tabla
$emaExistente = mysqli_query($conect, "SELECT * FROM estresusuarios WHERE email='$email' ");


//se obtienen todos los datos del usuario idUser
if($row = mysqli_fetch_array($emaExistente))
{
    $contrasena = $row['contrasena'];
    $nivelUsuario = $row['nivelEstres'];

    if($contrasena == $contra)
    {
    	 echo "inicia sesion";
    	 echo ",";
    	 echo $nivelUsuario;
    }
    else
    {
		echo "Error! Los datos son incorrectos";
    }
}else
{
    echo "Error! Los datos son incorrectos";	
}

//localhost:8888/estresPhp/iniciarSesion.php?ema=n@correo.com&con=n 

?>