<?php
	//conexion a la BD
	//echo "HOLA SOY LA CONEXION - EN CASA";
	/*$dbname = 'estres';
	$dbuser = 'estresUsuario';
	$dbpass = 'estres2020';
	$dbhost = 'localhost';

	//usuario: estresUsuario
	//clave: estres2020
	*/

//CONEXIÓN DE  BD CLASE
include ("conexion.php");

 //-------------------------------------------------------------------------
$estres = $_REQUEST['est'];

	//pregunto si el tipo de estrés esta en la tabla ejercicio
	$estresExistente = mysqli_query($conect, "SELECT * FROM estresEjercicio WHERE fEstres='$estres' ");

	//se obtienen todos los datos del usuario idUser
	while($row = mysqli_fetch_array($estresExistente))
	{
	    $eje1 = $row['ejer1'];
	    $eje2 = $row['ejer2'];
	    $eje3 = $row['ejer3'];
	    $eje4 = $row['ejer4'];
	    
	    echo ",";
	    echo $eje1;
	    echo ",";
	    echo $eje2;
	    echo ",";
	    echo $eje3;
	    echo ",";
	    echo $eje4;
	}
	//DIRECCION EN CASA
	//localhost:8888/estresPhp/leerEjercicio.php?est=

	//DIRECCION BD CLASE
	//http://tadeolabhack.com:8081/test/Datos/estresPhp/leerEjercicio?est=
	
	//http://tadeolabhack.com:8081/test/Datos/estresPhp/leerEjercicio.php



?>