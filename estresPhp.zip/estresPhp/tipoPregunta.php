<?php
//conexion a la BD
include ("conexion.php");

// RELACIONAR TABLA TIPO ESTRES CON PREGUNTAS ----------------------------------------------------
//-------------tipo estres--------------------------
//identifique los id de la tabla tipoestres 
$tipoestresID = $_REQUEST["idTE"];

//pregunto si el id esta en la tabla
$IDexistente = mysqli_query($conect, "SELECT * FROM estresTipoEstres WHERE id='$tipoestresID' ");

//se obtienen todos los datos deL ID
while($row = mysqli_fetch_array($IDexistente))
{
	$idNivel = $row['id'];

    echo $idNivel;
}

//-------------preguntas--------------------------
//identifique los id de la tabla preguntas
$idpregunta = $_REQUEST["preg"];

//pregunto si el id esta en la tabla
$preguntaExiste = mysqli_query($conect, "SELECT * FROM estresPreguntas WHERE id='$idpregunta' ");

//se obtienen todos los datos deL ID
while($row = mysqli_fetch_array($preguntaExiste))
{
	$preguntaD = $row['pregunta'];

    echo $preguntaD;
}


//-------------Tabla tipo pregunta FORANEA--------------------------
//insertar Valores en la tabla
$adicionarDatos = mysqli_query($conect, "INSERT INTO estresTipoPreguntas(idTipoEstres_FK,idTipoPreguntas_FK) VALUES('$idNivel','$preguntaD')");


//DIRECCION EN CASA
//localhost:8888/estresPhp/tipoPregunta.php?idTE=&preg=
  
//DIRECCION BD CLASE
//http://tadeolabhack.com:8081/test/Datos/tipoPregunta.php?idTE=&preg=
?>
