<?php
//conexion a la BD
include ("conexion.php");

// ------------------------------------REGISTRE UN USUARIO -------------------

//recibe los datos de unity, usamos el valor de estas variables
$nombre = $_REQUEST['nom'];
$email = $_REQUEST['ema'];
$contrasena = $_REQUEST['cont'];
$estres= $_REQUEST['nivel'];

  //insertar Valores en la base
$adicionarDatos = mysqli_query($conect, "INSERT INTO estresusuarios(nombre,email,contrasena,nivelEstres) VALUES('$nombre','$email','$contrasena',$estres)");

 echo "adicionado";



//DIRECCION EN CASA
//localhost:8888/estresPhp/registro.php?nom=toño&ema=tonito@correo.com&cont=123&nivel=2
  
//DIRECCION BD CLASE
//http://tadeolabhack.com:8081/test/Datos/estresPhp/registro.php?nom=usuario3&ema=usuario3@correo.com&cont=c123&nivel=3

?>