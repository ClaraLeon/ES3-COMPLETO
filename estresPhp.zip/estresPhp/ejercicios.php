<?php
//conexion a la BD
include ("conexion.php");

//------------------------------------- ESCRIBIR EJERCICIOS ----------------------------------------------------
$estres = $_REQUEST['es'];
$ejerc1= $_REQUEST['ej1'];
$ejerc2= $_REQUEST['ej2'];
$ejerc3= $_REQUEST['ej3'];
$ejerc4= $_REQUEST['ej4'];
$ejerc5= $_REQUEST['ej5'];
$ejerc6= $_REQUEST['ej6'];
$ejerc7= $_REQUEST['ej7'];
$ejerc8= $_REQUEST['ej8'];

//LINEA DE CÓDIGO EN CASA
$adicionarDatos = mysqli_query($conect, "INSERT INTO estresEjercicio(fEstres,ejer1,ejer2,ejer3,ejer4,ejer5,ejer6,ejer7,ejer8) VALUES('$estres','$ejerc1','$ejerc2','$ejerc3','$ejerc4','$ejerc5','$ejerc6','$ejerc7','$ejerc8')");


 echo "adicionado";


//DIRECCION EN CASA
//localhost:8888/estresPhp/ejercicios.php?es=1&ej1=Inhala y exhala. Repite tres veces ji ji jojo&ej2=Invéntate una risa explosiva&ej3=Puedes imitar la risa de una bruja &ej4=Si fueras un súper villano. Cuál seria tu risa malvada &ej5=Cómo es tu mejor risa &ej6=Intenta reírte sin hacer ningún ruido &ej7=Toma mucho aire. A continuación ríete hasta que quedes sin aire. Al finalizar. respira profundo &ej8=Respira profundo. Empieza riéndote muy suave y poco a poco aumenta el volumen de tu risa.

 //localhost:8888/estresPhp/ejercicios.php?&es=2&ej1=Intenta reírte como Bob esponja&ej2=Piensa rápidamente en un personaje con risa graciosa. Intenta imitarlo&ej3=Simplemente ríete y prolonga tu risa lo más que puedas.&ej4=Ríete haciendo una mueca&ej5=Respira profundo y suelta el aire diciendo JA  JA JA ... Hasta quedar sin aire. Inténtalo dos veces&ej6=Respira profundo y suelta el aire diciendo JE  JE JE ... Hasta quedar sin aire. Inténtalo dos veces&ej7=Respira profundo y suelta el aire diciendo JA JE JI JO JU ... Hasta quedar sin aire. Inténtalo dos veces&ej8=Respira profundo y suelta el aire diciendo JO JO JO ... Hasta quedar sin aire. Inténtalo dos veces


 //localhost:8888/estresPhp/ejercicios.php?es=3&ej1=Pon tu boca de tal manera que formes una "O" con tus labios. Ahora. Ríete jo jo jo prolongada mente.&ej2=Cómo se ríen los payasos. Intenta reírte como uno de ellos.&ej3=Has una risa estruendosa&ej4=Has una expresión de seriedad y a continuación ríete de la manera más aburrida.&ej5=Respira profundo y suelta el aire diciendo JI JI JI ... Hasta quedar sin aire. Inténtalo dos veces&ej6=Toma aire  y lentamente suelta el aire diciendo ji ji ji.&ej7=Respira profundo y suelta el aire diciendo JE  JE JE ... Hasta quedar sin aire. Inténtalo dos veces&ej8=Concéntrate y piensa en un recuerdo gracioso. Ahora. piensa en lo que te causo gracia en ese momento y poco a poco empieza soltar tu risa


//DIRECCION BD CLASE
//http://tadeolabhack.com:8081/test/Datos/estresPhp/ejercicios.php?es=1&ej1=Inhala y exhala. Repite tres veces ji ji jojo&ej2=Invéntate una risa explosiva&ej3=Puedes imitar la risa de una bruja &ej4=Si fueras un súper villano. Cuál seria tu risa malvada &ej5=Cómo es tu mejor risa &ej6=Intenta reírte sin hacer ningún ruido &ej7=Toma mucho aire. A continuación ríete hasta que quedes sin aire. Al finalizar. respira profundo &ej8=Respira profundo. Empieza riéndote muy suave y poco a poco aumenta el volumen de tu risa.


//http://tadeolabhack.com:8081/test/Datos/estresPhp/ejercicios.php?&es=2&ej1=Intenta reírte como Bob esponja &ej2=Piensa rápidamente en un personaje con risa graciosa. Intenta imitarlo&ej3=Simplemente ríete y prolonga tu risa lo más que puedas.&ej4=Ríete haciendo una mueca&ej5=Respira profundo y suelta el aire diciendo JA  JA JA ... Hasta quedar sin aire. Inténtalo dos veces&ej6=Respira profundo y suelta el aire diciendo JE  JE JE ... Hasta quedar sin aire. Inténtalo dos veces&ej7=Respira profundo y suelta el aire diciendo JA JE JI JO JU ... Hasta quedar sin aire. Inténtalo dos veces&ej8=Respira profundo y suelta el aire diciendo JO JO JO ... Hasta quedar sin aire. Inténtalo dos veces



 //http://tadeolabhack.com:8081/test/Datos/estresPhp/ejercicios.php?es=3&ej1=Pon tu boca de tal manera que formes una "O" con tus labios. Ahora. Ríete jo jo jo prolongada mente.&ej2=Cómo se ríen los payasos. Intenta reírte como uno de ellos.&ej3=Has una risa estruendosa&ej4=Has una expresión de seriedad y a continuación ríete de la manera más aburrida.&ej5=Respira profundo y suelta el aire diciendo JI JI JI ... Hasta quedar sin aire. Inténtalo dos veces&ej6=Toma aire  y lentamente suelta el aire diciendo ji ji ji.&ej7=Respira profundo y suelta el aire diciendo JE  JE JE ... Hasta quedar sin aire. Inténtalo dos veces&ej8=Concéntrate y piensa en un recuerdo gracioso. Ahora. piensa en lo que te causo gracia en ese momento y poco a poco empieza soltar tu risa