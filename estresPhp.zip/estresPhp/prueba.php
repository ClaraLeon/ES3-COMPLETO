<?php


$dbname = 'UnityDB';
$dbuser = 'camilo';
$dbpass = 'Noviembre2018';
$dbhost = 'localhost';

//conectarce al servidor mysql  (servidor,user,pasword,NombreBD)
$conect = new mysqli($dbhost, $dbuser, $dbpass,$dbname);


//recibe los datos de unity, usamos el valor de estas variables
$estres = $_REQUEST['es'];


//pregunto si el id de usuario ya esta en la tabla
$IDexistente = mysqli_query($conect, "SELECT * FROM estrespreguntas WHERE festres='$estres' ");


//se obtienen todos los datos del usuario idUser
while($row = mysqli_fetch_array($IDexistente))
{
    $p1 = $row['pregunta1'];
    $p2 = $row['pregunta2'];
    $p3 = $row['pregunta3'];
    $p4 = $row['pregunta4'];
    $p5 = $row['pregunta5'];

    echo $p1;
    echo ",";
    echo $p2;
    echo ",";
    echo $p3;
    echo ",";
	echo $p4;
    echo ",";
    echo $p5;    
}



//http://tadeolabhack.com:8081/test/Datos/leer.php?ape=pso


?>
