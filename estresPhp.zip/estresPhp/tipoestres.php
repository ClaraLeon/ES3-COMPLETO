<?php
//conexion a la BD
include ("conexion.php");

//------------------------------------- ESCRIBIR TIPO ESTRES ----------------------------------------------------
$tipoestresID = $_REQUEST['id'];
$tipoestres = $_REQUEST['tipoEs'];

//LINEA DE CÓDIGO EN CASA
$adicionarDatos = mysqli_query($conect, "INSERT INTO estresTipoEstres(id,tipoEstres) VALUES('$id','$tipoestres')");


  echo "adicionado";


//DIRECCION EN CASA
//localhost:8888/estresPhp/tipoestres.php?id=&tipoEs=Toda la semana
  
//DIRECCION BD CLASE
//http://tadeolabhack.com:8081/test/Datos/estresPhp/tipoestres.php?id=&tipoEs=1 a2 veces por semana

?>
