
<?php

//conexion a la BD
//echo "HOLA SOY LA CONEXION - EN CASA";
	$dbname = 'estres';
	$dbuser = 'estresUsuario';
	$dbpass = 'estres2020';
	$dbhost = 'localhost';

	//usuario: estresUsuario
	//clave: estres2020
	
//CONEXIÓN DE  BD CLASE
/*$dbname = 'UnityDB';
$dbuser = 'camilo';
$dbpass = 'Noviembre2018';
$dbhost = 'localhost';*/

//conectarce al servidor mysql  (servidor,user,pasword,NombreBD)
$conect = new mysqli($dbhost, $dbuser, $dbpass,$dbname);
//-------------------------------------------------------------------------

	$estres = $_REQUEST['est'];

	//pregunto si el nombre de usuario ya esta en la tabla usuarios
	$estresExistente = mysqli_query($conect, "SELECT * FROM estresPreguntas WHERE fEstres='$estres' ");

	//se obtienen todos los datos del usuario idUser
	while($row = mysqli_fetch_array($estresExistente))
	{
	    $p1 = $row['pregunta1'];
	    $p2 = $row['pregunta2'];
	    $p3 = $row['pregunta3'];
	    $p4 = $row['pregunta4'];
	    $p5 = $row['pregunta5'];
	    
	    echo $p1;
	    echo ",";
	    echo $p2;
	    echo ",";
	    echo $p3;
	    echo ",";
	    echo $p4;
	    echo ",";
	    echo $p5;
	}

	//DIRECCION EN CASA
	//localhost:8888/estresPhp/evaluacion.php?est=

	//DIRECCION BD CLASE
	//http://tadeolabhack.com:8081/test/Datos/estresPhp/evaluacion.php

?>