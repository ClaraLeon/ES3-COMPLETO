<?php
//conexion a la BD
include ("conexion.php");

//recibe los datos de unity, usamos el valor de estas variables
$userID = $_REQUEST['id'];
$nombre = $_REQUEST['nom'];
$email = $_REQUEST['ema'];
$contrasena = $_REQUEST['cont'];


//insertar Valores en la base de datos de la clase. Tabla: estresUsuarios

//LINEA DE CÓDIGO EN CASA
$adicionarDatos = mysqli_query($conect, "INSERT INTO estresusuarios(id,nombre,email,contrasena) VALUES('$id','$nombre','$email','$contrasena')");

//LINEA DE CÓDIGO BD CLASE
/*$adicionarDatos = mysqli_query($conect, "INSERT INTO estresUsuarios(id,nombre,email,contrasena) VALUES('$id','$nombre','$email','$contrasena')");*/

  echo "adicionado";


//DIRECCION EN CASA
//localhost:8888/estresPhp/escribir.php?id=&nom=usuarioPrueba&ema=usuario@correo.com&cont=123
  //localhost:8888/estresPhp/escribir.php?id=&tipoEs=Toda la semana

//DIRECCION BD CLASE
//http://tadeolabhack.com:8081/test/Datos/estresPhp/escribir.php?id=&nom=usuario2&ema=usuario2@correo.com&cont=contr

?>
