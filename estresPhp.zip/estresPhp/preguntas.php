<?php
//conexion a la BD
include ("conexion.php");

//------------------------------------- ESCRIBIR PREGUNTAS ----------------------------------------------------
$nestres = $_REQUEST['est'];
$p1 = $_REQUEST['p1'];
$p2 = $_REQUEST['p2'];
$p3 = $_REQUEST['p3'];
$p4 = $_REQUEST['p4'];
$p5 = $_REQUEST['p5'];


//LINEA DE CÓDIGO EN CASA
$adicionarDatos = mysqli_query($conect, "INSERT INTO estresPreguntas(fEstres,pregunta1,pregunta2,pregunta3,pregunta4,pregunta5) VALUES('$nestres','$p1','$p2','$p3','$p4','$p5')");


 echo "adicionado";


//DIRECCION EN CASAç
 //http://localhost:8888/estresPhp/preguntas.php?est=1&p1=Has dejado que tu trabajo se acumule&p2=Alguien ha sido grosero contigo&p3=Alguien te ha gritado&p4=Te han presionado por entregar un trabajo&p5=Has tenido mucho trabajo

 //http://localhost:8888/estresPhp/preguntas.php?est=2&p1=La cantidad de trabajo ha sido excesiva&p2=Has durado mucho tiempo en una misma actividad&p3=No has alcanzado la meta diaria&p4=Se arruino un trabajo&p5=Atendiste varias solicitudes al mismo tiempo


//DIRECCION BD CLASE
//http://tadeolabhack.com:8081/test/Datos/estresPhp/preguntas.php?est=1&p1=Has dejado que tu trabajo se acumule&p2=Alguien ha sido grosero contigo&p3=Alguien te ha gritado&p4=Te han presionado por entregar un trabajo&p5=Has tenido mucho trabajo

 //http://tadeolabhack.com:8081/test/Datos/estresPhp/preguntas.php?est=2&p1=La cantidad de trabajo ha sido excesiva&p2=Has durado mucho tiempo en una misma actividad&p3=No has alcanzado la meta diaria&p4=Se arruino un trabajo&p5=Atendiste varias solicitudes al mismo tiempo

  //http://tadeolabhack.com:8081/test/Datos/estresPhp/preguntas.php?est=3&p1=Has tenido que hacer el trabajo tu sol@&p2=El trabajo se hizo de una manera desordenada&p3=Has tenido una mala actitud con los demás&p4=Tu jefe ha tenido una mala actitud contigo&p5=Tus compañeros no estuvieron comprometidos con el trabajo
?>
